#!/bin/bash

g++ -O3 apriori.cpp -o apriori
g++ -O3 fptree.cpp -o fptree
