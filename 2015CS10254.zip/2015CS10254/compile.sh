#!/bin/bash

g++ -O3 -std=c++11 kmeans.cpp -o kmeans
g++ -O3 -std=c++11 dbscan.cpp -o dbscan
g++ -O3 -std=c++11 optics.cpp -o optics
